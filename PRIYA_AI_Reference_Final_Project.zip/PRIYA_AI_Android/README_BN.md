# PRIYA AI – Android Studio Source Project

## এই সংস্করণে
- হোম স্ক্রিনে পূর্ণ-স্ক্রিন ব্যাকগ্রাউন্ড; ব্যবহারকারীর দেওয়া ৩টি মূল ছবি থেকে যেকোনো একটি বেছে নেওয়া যায়।
- সিস্টেম Gallery/Photo Picker নেই; Settings-এ শুধু bundled তিনটি ছবি দেখানো হয়।
- হোম স্ক্রিনে আলাদা “Hi, I'm Priya” লেখা বা ভিতরে লোগো দেখানো হয় না।
- বড় গোল মাইক্রোফোন বাটনে চাপলে বাংলা Speech Recognizer চালু হয়।
- পাশে Telegram আইকন; চাপলে https://t.me/gameroftom খুলবে।
- Gemini API Key Settings-এ যোগ করে Chat উত্তর পাওয়া যায়।
- YouTube, WhatsApp, Chrome ও Telegram খোলার সাধারণ voice/text command।
- বাংলা Text-to-Speech ডিভাইসে থাকা কণ্ঠের ওপর নির্ভর করে।

## APK বানানো
1. Android Studio-তে `PRIYA_AI_Android` ফোল্ডার Open করুন।
2. Gradle Sync করুন (JDK 17)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s)।
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`।

## API Key
Settings থেকে Google AI Studio API Key দিন: https://aistudio.google.com/app/apikey

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি Android Studio source project; এখানে APK build বা device testing করা হয়নি।
- অ্যাপটি Android-এর অনুমোদিত intents দিয়ে কিছু অ্যাপ খুলতে পারে; ফোনের unrestricted/full access নেই এবং Root লাগে না।
- WhatsApp-এ কাউকে নিজে থেকে মেসেজ পাঠায় না; WhatsApp খোলে, পাঠানো ব্যবহারকারীকে নিজে করতে হয়।
- Voice recognition ও TTS Android-এর উপলব্ধ ভাষা/voice engine-এর ওপর নির্ভরশীল।
- পাবলিকভাবে বিতরণের production app-এ API Key সরাসরি client-এ রাখা নিরাপদ নয়; backend proxy ব্যবহার করা উচিত।
