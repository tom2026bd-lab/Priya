package com.priya.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var prefs: SharedPreferences
    private lateinit var tts: TextToSpeech
    private lateinit var router: CommandRouter
    private lateinit var chat: TextView
    private lateinit var status: TextView
    private lateinit var bg: ImageView
    private lateinit var logo: ImageView
    private var recognizer: SpeechRecognizer? = null
    private var pulse: ObjectAnimator? = null
    private var ttsReady = false
    private val history = mutableListOf<Pair<String, String>>()
    private val bgs = intArrayOf(R.drawable.bg1, R.drawable.bg2, R.drawable.bg3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("priya", Context.MODE_PRIVATE)
        router = CommandRouter(this)
        chat = findViewById(R.id.chat); status = findViewById(R.id.status)
        bg = findViewById(R.id.bg); logo = findViewById(R.id.logo)
        bg.setImageResource(bgs[prefs.getInt("bg", 0) % bgs.size])

        findViewById<Button>(R.id.btnTelegram).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/gameroftom")))
        }
        findViewById<Button>(R.id.btnBg).setOnClickListener {
            val n = (prefs.getInt("bg", 0) + 1) % bgs.size
            prefs.edit().putInt("bg", n).apply(); bg.setImageResource(bgs[n])
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener { listen() }

        tts = TextToSpeech(this, this)
        if (!prefs.getBoolean("onboarded", false)) showOnboarding()
    }

    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) return
        val r = tts.setLanguage(Locale("bn", "BD"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US)
        tts.setPitch(1.3f); tts.setSpeechRate(0.95f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = runOnUiThread { startPulse() }
            override fun onDone(id: String?) = runOnUiThread { stopPulse() }
            @Deprecated("deprecated") override fun onError(id: String?) = runOnUiThread { stopPulse() }
        })
        ttsReady = true
        if (prefs.getBoolean("onboarded", false)) speak("হ্যালো বস, আমি প্রিয়া। বলো কী করতে পারি?")
    }

    private fun startPulse() {
        pulse?.cancel()
        pulse = ObjectAnimator.ofPropertyValuesHolder(logo,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f)).apply {
            duration = 450; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start()
        }
    }
    private fun stopPulse() { pulse?.cancel(); logo.scaleX = 1f; logo.scaleY = 1f }

    private fun speak(text: String) {
        addChat("প্রিয়া: $text")
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "priya")
    }

    private fun addChat(line: String) {
        chat.append(line + "\n\n")
        findViewById<ScrollView>(R.id.scroll).post { findViewById<ScrollView>(R.id.scroll).fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun listen() {
        val need = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
            .filter { checkSelfPermission(it) != 0 }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != 0) {
            requestPermissions(need.toTypedArray(), 1); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "এই ফোনে স্পিচ রিকগনিশন নেই"; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "শুনছি বস..." }
                override fun onResults(r: Bundle?) {
                    status.text = "প্রিয়া রেডি, বস"
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
                }
                override fun onError(e: Int) { status.text = "ঠিক শুনতে পারিনি, আবার বলো বস" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (prefs.getBoolean("en", false)) "en-US" else "bn-BD")
            })
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) listen()
    }

    private fun process(text: String) {
        addChat("তুমি: $text")
        val reply = router.handle(text)
        if (reply != null) { speak(reply); return }
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) { speak("বস, কথা বলতে হলে আগে সেটিংসে API key বসাও"); showSettings(); return }
        status.text = "ভাবছি..."
        val model = prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        Thread {
            val ans = AiChat.ask(key, model, history, text)
            runOnUiThread {
                history.add("user" to text); history.add("model" to ans)
                status.text = "প্রিয়া রেডি, বস"; speak(ans)
            }
        }.start()
    }

    private fun showSettings() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, 0) }
        val key = EditText(this).apply { hint = "Gemini API key"; setText(prefs.getString("key", "")) }
        val model = EditText(this).apply { hint = "মডেল (যেমন gemini-2.5-flash)"; setText(prefs.getString("model", "gemini-2.5-flash")) }
        val en = CheckBox(this).apply { text = "ইংরেজিতে শোনো (English)"; isChecked = prefs.getBoolean("en", false) }
        box.addView(key); box.addView(model); box.addView(en)
        AlertDialog.Builder(this).setTitle("সেটিংস").setView(box)
            .setPositiveButton("সেভ") { _, _ ->
                prefs.edit().putString("key", key.text.toString().trim())
                    .putString("model", model.text.toString().trim().ifEmpty { "gemini-2.5-flash" })
                    .putBoolean("en", en.isChecked).apply()
            }
            .setNeutralButton("Accessibility চালু করো") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("বাতিল", null).show()
    }

    private fun showOnboarding() {
        AlertDialog.Builder(this).setTitle("স্বাগতম, বস")
            .setMessage("প্রিয়ার কিছু অনুমতি লাগবে:\n\n• মাইক: তোমার কথা শোনার জন্য\n• ফোন ও কন্ট্যাক্ট: কল করার জন্য\n• Accessibility: Back, Home, স্ক্রিনশট কমান্ডের জন্য (সেটিংস থেকে নিজে চালু করতে হবে)\n• ইন্টারনেট: AI-র সাথে কথা বলার জন্য\n\nকথোপকথনের জন্য সেটিংসে নিজের Gemini API key বসাতে হবে।")
            .setPositiveButton("ঠিক আছে") { _, _ ->
                prefs.edit().putBoolean("onboarded", true).apply()
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS), 1)
                if (ttsReady) speak("হ্যালো বস, আমি প্রিয়া। বলো কী করতে পারি?")
            }.setCancelable(false).show()
    }

    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
}
