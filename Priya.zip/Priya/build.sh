#!/data/data/com.termux/files/usr/bin/bash
# Termux এ চেষ্টা করার স্ক্রিপ্ট। Android SDK (ANDROID_HOME) আগে থেকে সেট থাকতে হবে।
# সবচেয়ে নির্ভরযোগ্য উপায়: GitHub Actions (README দেখো)।
pkg update -y && pkg install -y openjdk-17 gradle aapt2
grep -q aapt2FromMavenOverride gradle.properties || echo "android.aapt2FromMavenOverride=$PREFIX/bin/aapt2" >> gradle.properties
gradle assembleDebug
echo "APK: app/build/outputs/apk/debug/"
