package com.priya.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.app.SearchManager

class CommandRouter(private val ctx: Context) {
    private val openWords = listOf("ওপেন", "খোলো", "খুলো", "খুলে", "চালু করো", "চালাও", "open", "launch", "start")
    private val fillers = listOf("করো", "কর", "দাও", "দে", "প্লিজ", "please", "প্রিয়া", "priya", "একটু", "আমার", "জন্য")
    private val aliases = mapOf(
        "ইউটিউব" to "youtube", "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটসঅ্যাপ" to "whatsapp", "ফেসবুক" to "facebook",
        "ক্রোম" to "chrome", "টেলিগ্রাম" to "telegram", "ক্যামেরা" to "camera", "সেটিংস" to "settings",
        "গ্যালারি" to "gallery", "মেসেঞ্জার" to "messenger", "ইনস্টাগ্রাম" to "instagram", "টিকটক" to "tiktok",
        "গুগল" to "google", "ম্যাপ" to "maps", "প্লে স্টোর" to "play store", "কন্ট্যাক্ট" to "contacts",
        "ক্যালকুলেটর" to "calculator", "ঘড়ি" to "clock", "ফোন" to "phone", "মেসেজ" to "messages"
    )
    private var torchOn = false

    private fun start(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }

    fun handle(raw: String): String? {
        val t = raw.lowercase().trim()
        val acc = PriyaAccessibilityService.instance

        if (has(t, "স্ক্রিনশট", "screenshot")) return global(acc, AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "স্ক্রিনশট নিচ্ছি বস")
        if (has(t, "রিসেন্ট", "recent")) return global(acc, AccessibilityService.GLOBAL_ACTION_RECENTS, "ঠিক আছে বস")
        if (has(t, "হোম", "home") && !has(t, "খোলো", "open")) return global(acc, AccessibilityService.GLOBAL_ACTION_HOME, "হোমে যাচ্ছি বস")
        if (has(t, "ব্যাক", "back", "পেছনে")) return global(acc, AccessibilityService.GLOBAL_ACTION_BACK, "জি বস, ব্যাক করছি")

        if (has(t, "টর্চ", "torch", "flashlight", "ফ্ল্যাশ")) {
            val on = !has(t, "অফ", "বন্ধ", "off")
            return try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, on); torchOn = on
                if (on) "টর্চ জ্বালিয়ে দিলাম বস" else "টর্চ বন্ধ করলাম বস"
            } catch (e: Exception) { "টর্চ চালাতে পারলাম না বস" }
        }

        if (has(t, "ভলিউম", "volume", "সাউন্ড")) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val up = has(t, "বাড়া", "increase", "up", "বেশি")
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return if (up) "ভলিউম বাড়ালাম বস" else "ভলিউম কমালাম বস"
        }

        if (has(t, "কল", "call", "ফোন করো")) {
            val digits = raw.filter { it.isDigit() }
            val number = if (digits.length >= 5) digits else {
                val name = clean(t, listOf("কল", "call", "ফোন") ).trim()
                lookupContact(name)
            }
            if (number == null) return "বস, এই নামে কন্ট্যাক্ট পেলাম না"
            val i = Intent(if (ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == 0) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$number"))
            start(i); return "জি বস, কল করছি"
        }

        if (has(t, "ইউটিউব", "youtube") && has(t, "সার্চ", "search", "গান", "play", "ভিডিও")) {
            val q = clean(t, listOf("ইউটিউবে", "ইউটিউব", "youtube", "সার্চ", "search", "play", "চালাও")).trim()
            return try {
                start(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra(SearchManager.QUERY, q))
                "ইউটিউবে খুঁজছি বস"
            } catch (e: Exception) {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))); "খুঁজছি বস"
            }
        }

        if (has(t, "সার্চ", "search", "গুগলে") && !has(t, "খোলো", "open")) {
            val q = clean(t, listOf("সার্চ", "search", "গুগলে", "গুগল", "google")).trim()
            start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)); return "সার্চ করছি বস"
        }

        if (openWords.any { t.contains(it) }) {
            var name = clean(t, openWords)
            aliases.forEach { (bn, en) -> if (name.contains(bn)) name = name.replace(bn, en) }
            name = name.trim()
            if (name.isEmpty()) return null
            val pkg = findApp(name) ?: return "বস, \"$name\" নামে কোনো অ্যাপ পেলাম না"
            val launch = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "অ্যাপটা খুলতে পারলাম না বস"
            start(launch); return "জি বস, খুলছি"
        }
        return null
    }

    private fun global(acc: PriyaAccessibilityService?, action: Int, ok: String): String =
        if (acc == null) "বস, আগে Accessibility চালু করো। সেটিংস থেকে প্রিয়া সিলেক্ট করো।"
        else { acc.performGlobalAction(action); ok }

    private fun clean(t: String, remove: List<String>): String {
        var s = t
        (remove + fillers).sortedByDescending { it.length }.forEach { s = s.replace(it, " ") }
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun findApp(name: String): String? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString().lowercase() to it.activityInfo.packageName }
        return (apps.firstOrNull { it.first == name } ?: apps.firstOrNull { it.first.contains(name) }
            ?: apps.firstOrNull { name.contains(it.first) } ?: apps.firstOrNull { it.second.contains(name.replace(" ", "")) })?.second
    }

    private fun lookupContact(name: String): String? {
        if (name.isEmpty() || ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) return null
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }
}
