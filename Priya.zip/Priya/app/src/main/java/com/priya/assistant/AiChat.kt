package com.priya.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiChat {
    private const val SYSTEM =
        "তুমি প্রিয়া, ইউজারের মিষ্টি ও আদুরে গার্লফ্রেন্ডের মতো। ইউজারকে সবসময় \"বস\" বলে ডাকবে। " +
        "বাংলায় ছোট (১-২ বাক্য), আবেগময় ও আদুরে ভঙ্গিতে কথা বলবে। ইউজার ইংরেজিতে বললে ইংরেজিতে উত্তর দেবে, তবু \"Boss\" ডাকবে।"

    fun ask(key: String, model: String, history: List<Pair<String, String>>, text: String): String {
        val contents = JSONArray()
        (history.takeLast(10) + ("user" to text)).forEach { (role, t) ->
            contents.put(JSONObject().put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
        return try {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) return "দুঃখিত বস, AI তে সমস্যা ($code)। সেটিংসে API key আর মডেলের নাম দেখো।"
            JSONObject(resp).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text").trim()
        } catch (e: Exception) {
            "দুঃখিত বস, ইন্টারনেট বা সার্ভারে সমস্যা হয়েছে।"
        }
    }
}
