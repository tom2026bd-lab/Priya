# Priya (প্রিয়া)

## APK বানানোর সহজ উপায় (GitHub Actions)
1. github.com এ নতুন repo বানাও, এই প্রজেক্টের সব ফাইল (`.github` ফোল্ডারসহ) আপলোড করো।
2. Actions ট্যাব → "Build APK" → Run workflow।
3. শেষ হলে Artifacts থেকে Priya-APK ডাউনলোড করে ইনস্টল করো।

## Termux এ
`bash build.sh` (Android SDK আগে থেকে সেটআপ থাকতে হবে, তাই এটা ঝামেলার)।

## ব্যবহার
- সেটিংসে নিজের Gemini API key বসাও (aistudio.google.com এ ফ্রি)
- Accessibility চালু করো (সেটিংস → Accessibility চালু করো)
- মাইক চেপে বলো: "YouTube ওপেন করো", "রহিমকে কল করো", "টর্চ জ্বালাও", "স্ক্রিনশট নাও"
