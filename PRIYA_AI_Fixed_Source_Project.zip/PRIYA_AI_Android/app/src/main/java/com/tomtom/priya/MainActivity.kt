package com.tomtom.priya

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

private val Night = Color(0xFF070614)
private val Violet = Color(0xFF9855FF)
private val Pink = Color(0xFFFF79D2)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { PriyaApp(onSpeak = { speak(it) }) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("bn", "BD")
            tts?.setSpeechRate(0.90f)
            tts?.setPitch(1.15f)
        }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "priya_reply") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
fun PriyaApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("priya_settings", 0) }
    var page by remember { mutableStateOf("home") }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var bgIndex by remember { mutableIntStateOf(prefs.getInt("bg", 1).coerceIn(0, 2)) }
    var input by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val backgrounds = listOf(R.drawable.bg_one, R.drawable.bg_two, R.drawable.bg_three)

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) { input = spoken; runCommandOrChat(context, spoken, apiKey, { reply = it; busy = false; onSpeak(it) }, { busy = it }) }
    }
    fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বস, বলো কী করতে হবে")
        }
        try { voiceLauncher.launch(intent) } catch (_: Exception) { Toast.makeText(context, "Voice recognition is not available", Toast.LENGTH_SHORT).show() }
    }

    Box(Modifier.fillMaxSize().background(Night)) {
        // The selected original user image remains the full-screen background.
        Image(painterResource(backgrounds[bgIndex]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x33060512), Color(0x66070614), Color(0xF5070614)))))
        if (page == "settings") {
            Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 28.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { page = "home" }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                    Text("Settings", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                SettingsPage(apiKey, { apiKey = it }, bgIndex, { bgIndex = it; prefs.edit().putInt("bg", it).apply() },
                    onSave = { prefs.edit().putString("api_key", apiKey.trim()).apply(); Toast.makeText(context, "API Key saved", Toast.LENGTH_SHORT).show() })
            }
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
                // Header: no avatar/logo and no “Hi, I'm Priya” labels.
                Row(Modifier.fillMaxWidth().padding(top = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlowIconButton(Icons.Default.Menu) { page = "settings" }
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("PRIYA AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
                        Text("YOUR AI ASSISTANT", color = Color(0xFFD9C7FF), fontSize = 9.sp, letterSpacing = 3.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    GlowIconButton(Icons.Default.Settings) { page = "settings" }
                }
                // Hero space lets the full-screen background artwork remain visible behind the controls.
                Spacer(Modifier.weight(0.85f))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(206.dp).shadow(28.dp, CircleShape).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF2C145F), Color(0xFF09071B), Color(0xFF4B1B83))))
                        .clickable { startVoice() }, contentAlignment = Alignment.Center) {
                        Box(Modifier.fillMaxSize().padding(8.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color(0xFF3B1C70), Color(0xFF100B29), Color(0xFF070614)))))
                        Icon(Icons.Default.Mic, null, tint = Color(0xFFD8B7FF), modifier = Modifier.size(76.dp))
                    }
                    // Telegram shortcut at the side; opens the user's channel.
                    Box(Modifier.align(Alignment.CenterEnd).offset(x = 8.dp, y = (-126).dp)
                        .size(52.dp).shadow(12.dp, CircleShape).clip(CircleShape)
                        .background(Color(0xFF229ED9)).clickable {
                            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://t.me/gameroftom")))
                        }, contentAlignment = Alignment.Center) {
                        Image(painterResource(R.drawable.ic_telegram), null, Modifier.size(28.dp))
                    }
                }
                Text("Tap to Talk", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 12.dp))
                Text("• • • • • 〰 • • • • •", color = Pink, fontSize = 16.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 5.dp, bottom = 18.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
                    .background(Color(0xDD171329)).padding(start = 14.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Violet, modifier = Modifier.size(27.dp))
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask me anything...", color = Color(0xFFAAA0C3)) }, singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent, cursorColor = Pink))
                    IconButton(enabled = !busy, onClick = {
                        val message = input.trim()
                        if (message.isNotEmpty()) { input = ""; runCommandOrChat(context, message, apiKey, { reply = it; busy = false; onSpeak(it) }, { busy = it }) }
                    }) { Icon(Icons.Default.Send, null, tint = Color.White, modifier = Modifier.size(27.dp)) }
                }
                if (reply.isNotBlank()) Text(reply, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp).fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PremiumTile("Chat", "Get instant answers", Icons.Default.Chat, Modifier.weight(1f)) { page = "chat" }
                    PremiumTile("Background", "3 included images", Icons.Default.Image, Modifier.weight(1f)) { page = "settings" }
                    PremiumTile("Write", "Notes, code, content", Icons.Default.Description, Modifier.weight(1f)) { page = "chat" }
                }
                Spacer(Modifier.weight(0.7f))
                Row(Modifier.fillMaxWidth().padding(bottom = 18.dp).clip(RoundedCornerShape(36.dp))
                    .background(Color(0xE51E1740)).padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically) {
                    NavItem(Icons.Default.Home, "Home", true) { page = "home" }
                    NavItem(Icons.Default.ChatBubble, "Chat") { page = "chat" }
                    Box(Modifier.size(70.dp).shadow(14.dp, CircleShape).clip(CircleShape)
                        .background(Brush.radialGradient(listOf(Color(0xFF8E49FF), Color(0xFF170D39))))
                        .clickable { startVoice() }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFE9C7FF), modifier = Modifier.size(32.dp))
                    }
                    NavItem(Icons.Default.History, "History") { Toast.makeText(context, "History এখনো যোগ করা হয়নি", Toast.LENGTH_SHORT).show() }
                    NavItem(Icons.Default.Settings, "Settings") { page = "settings" }
                }
            }
        }
    }
}

@Composable private fun GlowIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).clip(RoundedCornerShape(17.dp)).background(Color(0xAA171329))
        .clickable { onClick() }, contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(27.dp)) }
}

@Composable private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.clickable { onClick() }.padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (selected) Color(0xFFFFB84D) else Color(0xFFB7A8D8), modifier = Modifier.size(25.dp))
        Text(label, color = if (selected) Color(0xFFFFC15A) else Color(0xFFB7A8D8), fontSize = 11.sp)
    }
}

@Composable private fun PremiumTile(label: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color(0xDD171329)),
        shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x665F438E))) {
        Column(Modifier.fillMaxWidth().height(112.dp).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Pink, modifier = Modifier.size(25.dp))
            Spacer(Modifier.height(7.dp)); Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(sub, color = Color(0xFFAAA0C3), fontSize = 9.sp, maxLines = 1)
        }
    }
}

@Composable
fun SettingsPage(apiKey: String, onKey: (String) -> Unit, bgIndex: Int, onBg: (Int) -> Unit, onSave: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(top = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Gemini API Key", color = Color(0xFFE5D8FF), fontWeight = FontWeight.SemiBold)
        OutlinedTextField(value = apiKey, onValueChange = onKey, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Paste your API key") }, singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Save API Key") }
        Text("API Key নিতে Google AI Studio খুলুন:", color = Color.White)
        Text("aistudio.google.com/app/apikey", color = Pink, modifier = Modifier.clickable {
            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://aistudio.google.com/app/apikey")))
        })
        Divider(color = Color(0xFF51416B))
        Text("Choose Background (শুধু এই ৩টি ছবি)", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            (0..2).forEach { index ->
                Column(Modifier.weight(1f).clickable { onBg(index) }) {
                    Image(painterResource(listOf(R.drawable.bg_one, R.drawable.bg_two, R.drawable.bg_three)[index]),
                        "Background ${index + 1}", Modifier.fillMaxWidth().height(112.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                    Text(if (bgIndex == index) "✓ Selected" else "Background ${index + 1}", color = if (bgIndex == index) Pink else Color.White, fontSize = 11.sp)
                }
            }
        }
        Text("Voice: Android-এর উপলব্ধ বাংলা TTS কণ্ঠ ব্যবহার করে।", color = Color(0xFFDCCEFF), fontSize = 12.sp)
        Text("অ্যাপ খোলা Android-এর অনুমোদিত Intent দিয়ে হয়; Root প্রয়োজন নেই।", color = Color(0xFFDCCEFF), fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://t.me/gameroftom"))) },
            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229ED9))) {
            Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text("Telegram Channel")
        }
    }
}

fun runCommandOrChat(context: android.content.Context, message: String, apiKey: String,
                     onAnswer: (String) -> Unit, onBusy: (Boolean) -> Unit) {
    if (handlePhoneCommand(context, message)) { onAnswer("ঠিক আছে বস! অ্যাপটি খোলার চেষ্টা করেছি। 💜"); return }
    if (apiKey.isBlank()) { onAnswer("বস, আগে Settings থেকে Gemini API Key যোগ করো।"); return }
    onBusy(true); askGemini(apiKey, message, onAnswer)
}

fun openPackage(context: android.content.Context, packageName: String) {
    val launch = context.packageManager.getLaunchIntentForPackage(packageName)
    if (launch != null) context.startActivity(launch) else Toast.makeText(context, "এই অ্যাপটি ফোনে ইনস্টল করা নেই", Toast.LENGTH_SHORT).show()
}

fun handlePhoneCommand(context: android.content.Context, raw: String): Boolean {
    val text = raw.lowercase()
    return when {
        text.contains("youtube") || text.contains("ইউটিউব") -> { openPackage(context, "com.google.android.youtube"); true }
        text.contains("whatsapp") || text.contains("হোয়াটসঅ্যাপ") || text.contains("হোয়াটসঅ্যাপ") -> { openPackage(context, "com.whatsapp"); true }
        text.contains("telegram") || text.contains("টেলিগ্রাম") -> { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://t.me/gameroftom"))); true }
        text.contains("chrome") || text.contains("ক্রোম") -> { openPackage(context, "com.android.chrome"); true }
        else -> false
    }
}

fun askGemini(apiKey: String, prompt: String, done: (String) -> Unit) {
    thread {
        val answer = try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${URLEncoder.encode(apiKey, "UTF-8")}")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val systemPrompt = "তোমার নাম প্রিয়া। তুমি বসকে মিষ্টি, সম্মানজনক, স্নেহপূর্ণ বাংলা ভাষায় উত্তর দেবে। সবসময় তাকে 'বস' বলে ডাকবে। তুমি AI, বাস্তব মানুষ নও। ফোনের কাজ করতে না পারলে সেটা পরিষ্কার বলবে।"
            val body = JSONObject().put("system_instruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", systemPrompt))))
                .put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt)))))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val result = stream.bufferedReader().use { it.readText() }; conn.disconnect()
            val json = JSONObject(result)
            json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                ?: "দুঃখিত বস, এখন উত্তর আনতে পারছি না। API Key ও ইন্টারনেট পরীক্ষা করো।"
        } catch (_: Exception) { "বস, সংযোগে সমস্যা হয়েছে। ইন্টারনেট ও API Key পরীক্ষা করো।" }
        android.os.Handler(android.os.Looper.getMainLooper()).post { done(answer) }
    }
}
