# PRIYA AI — Android source project

এই ZIP-এ Android Studio source project এবং GitHub Actions workflow আছে। এটি আগে থেকে বানানো APK নয়। GitHub Actions বা Android Studio দিয়ে APK build করতে হবে।

## GitHub দিয়ে APK বানানোর নিয়ম
1. ZIP-টি ডাউনলোড করে Extract করুন।
2. Extract করা `PRIYA_AI_Android` ফোল্ডারের **ভেতরের সব ফাইল ও ফোল্ডার** আপনার GitHub repository-র root-এ upload করুন। ZIP ফাইলটিকে একা repository-তে upload করবেন না।
3. নিশ্চিত করুন repository root-এ `settings.gradle.kts`, `build.gradle.kts`, `app/` এবং `.github/workflows/build.yml` দেখা যাচ্ছে।
4. GitHub-এর Actions tab খুলুন। `Build PRIYA AI APK` workflow নির্বাচন করে `Run workflow` চাপুন; অথবা `main` branch-এ push হলে এটি নিজে চলবে।
5. সবুজ টিক-সহ run খুলে নিচের Artifacts অংশ থেকে `PRIYA-AI-APK` ডাউনলোড করুন। ZIP Extract করে `app-debug.apk` ইনস্টল করুন।

## Android Studio দিয়ে
- `PRIYA_AI_Android` ফোল্ডার Open করুন।
- JDK 17 এবং Android SDK Platform 35 ব্যবহার করুন।
- Gradle Sync করে `:app:assembleDebug` চালান।

## অ্যাপের বর্তমান ফিচার/সীমাবদ্ধতা
- ব্যবহারকারীর দেওয়া তিনটি ব্যাকগ্রাউন্ড ছবি ও PRIYA লোগো asset হিসেবে রাখা হয়েছে; Settings থেকে কেবল এই তিনটি ব্যাকগ্রাউন্ড বেছে নেওয়া যায়।
- বাংলা speech recognition Android-এর speech service-এর ওপর নির্ভর করে। Text-to-speech-ও ফোনে থাকা Bengali voice-এর ওপর নির্ভরশীল।
- Gemini chat-এর জন্য Settings-এ নিজের Gemini API key দিতে হবে। API key client app-এ রাখা production ব্যবহারের জন্য নিরাপদ নয়; public release-এর আগে backend proxy দরকার।
- YouTube, WhatsApp ও Chrome খোলার command আছে; Telegram command/channel shortcut নির্দিষ্ট channel খোলে। WhatsApp-এ মেসেজ নিজে পাঠায় না।
- History এবং কিছু quick tiles এখনো placeholder; সব voice action বা external app interaction সব ডিভাইসে নিশ্চিত নয়।
- এই source ZIP-কে এখানে Android SDK দিয়ে compile বা বাস্তব ফোনে পরীক্ষা করা হয়নি। GitHub Actions-এর Build সফল হলেই কেবল APK build নিশ্চিত হবে; ডিভাইস-পরীক্ষা আলাদা।
